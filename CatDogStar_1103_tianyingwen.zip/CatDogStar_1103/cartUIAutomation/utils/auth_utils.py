#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: auth_utils.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

import os

from cartUIAT.config.config import LOGIN_URL
from cartUIAT.config.config import USER_CREDENTIALS
from cartUIAT.config.config import STORAGE_STATE_PATH
from cartUIAT.utils.log import logger
from playwright.sync_api import sync_playwright


def login_and_save_auth_state():
    """
    执行登录并保存认证状态, 提供登录和状态管理功能
    此方法意在表明method的大体逻辑和方向，因login操作需要网络翻墙，暂时未实操登录。
    """
    with sync_playwright() as p:
        # 启动浏览器
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()
        
        try:
            # 导航到登录页面
            logger.info('打开登录页面')
            page.goto(LOGIN_URL)
            
            # 等待页面加载完成
            logger.info('等待登录页面加载完成')
            page.wait_for_load_state("networkidle")
            
            # 方案一：输入用户名和密码
            logger.info('输入用户名')
            page.fill('input[name="username"]', USER_CREDENTIALS["username"])
            logger.info('输入用户密码')
            page.fill('input[name="password"]', USER_CREDENTIALS["password"])

            # 点击登录按钮
            logger.info('点击登录')
            page.click('button[type="submit"]')
            
            # 等待登录完成，这里可以根据页面跳转或特定元素出现来判断
            page.wait_for_url("**/home")  # 假设登录后跳转到首页
            
            # 保存认证状态
            context.storage_state(path=STORAGE_STATE_PATH)
            print(f"认证状态已保存到: {STORAGE_STATE_PATH}")
            
        except Exception as e:
            print(f"登录过程中出现错误: {e}")
            raise
        finally:
            # 关闭浏览器
            browser.close()

def load_auth_state():
    """
    检查认证状态文件是否存在
    """
    return os.path.exists(STORAGE_STATE_PATH)

def clear_auth_state():
    """
    清除认证状态文件
    """
    if os.path.exists(STORAGE_STATE_PATH):
        os.remove(STORAGE_STATE_PATH)
        print(f"已清除认证状态文件: {STORAGE_STATE_PATH}")


if __name__ == "__main__":
    # 如果直接运行此脚本，则执行登录并保存状态
    login_and_save_auth_state()
