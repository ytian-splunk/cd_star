#!/usr/bin/env python3
# -*- code:utf-8 -*-
'''
@File: log.py
@Author: Tian Yingwen
@Date: 2025/10/20
'''

class Verify(object):
    def verify_true(self, value, msg=''):
        """Assert if value is True or not."""
        try:
            assert value
        except Exception:
            raise AssertionError(
                f'verify校验, 预期 {value} 为 True, 校验失败:{msg}')

    def verify_false(self, value, msg=''):
        """Assert if value is False or not."""
        try:
            # assert not value
            self.verify_true((not value), msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, 预期 {value} 为 False, 校验失败:{msg}')

    def verify_equal(self, first, second, msg=''):
        """Assert if first equal to second or not."""
        try:
            self.verify_true((first == second), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, 预期 {first} 等于 {second}, 校验失败:{msg}')

    def verify_int_equal(self, first, second, msg=''):
        """Assert if first equal self.verify.verify_false(o second or not."""
        if isinstance(first, int) and isinstance(second, int):
            self.verify_equal(first, second, msg=msg)

    def verify_not_equal(self, first, second, msg=''):
        """Assert if first not equal to second or not."""
        try:
            self.verify_true((first != second), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, 预期 {first} 不等于 {second}, 校验失败:{msg}')

    def verify_in(self, single, iterable, msg=''):
        """
        assert in
        :param single:
        :param iterable:
        :param msg:
        :return:
        """
        try:
            self.verify_true((single in iterable), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, {single} 预期包含在 {iterable} 中, 校验失败:{msg}'
            )

    def verify_in_single_of_multiple(self, single, *multiple_iterable):
        """
        assert in.
        判断一个string是否是另外多个string or list中的一部分. 比如，搜索框支持名称和id，
        比对keyword是名称 or id某个的一部分即可。
        :param single:
        :param iterable:
        :param msg:
        :return:
        """
        for item in multiple_iterable:
            if single in item:
                return True

        return False

    def verify_search_keywords(self, keyword, name, msg=''):
        """
        assert in
        :param keyword:
        :param keyword:
        :param msg:
        :return:
        """
        try:
            self.verify_true((keyword.lower() in name.lower()), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'{keyword} is not in {name}, error:{msg}')

    def verify_elems_in(self, elems, iterable, msg=''):
        """
        assert in
        :param elems: iterable
        :param iterable: iterable
        :param msg:
        :return:
        """
        assert type(elems) == list
        try:
            self.verify_true(all(elem in iterable for elem in elems), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, {elems} 的每一个元素, '
                f'预期都包含在 {iterable} 中, 校验失败:{msg}'
            )

    def verify_subdict_in(self, d1, d2, msg=''):
        """
        assert in
        :param d1: dict
        :param d2: dict
        :param msg:
        :return:
        """
        assert type(d1) == dict
        assert type(d2) == dict
        try:
            self.verify_true(d1.items() <= d2.items(), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'{d1} is not in {d2}, error:{msg}')

    def verify_not_in(self, single, iterable, msg=''):
        """
        assert not in
        :param single:
        :param iterable: iterable
        :param msg:
        :return:
        """
        try:
            self.verify_false((single in iterable), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, [{single}] '
                f'预期不包含在[{iterable}] 中, 校验失败:{msg}'
            )

    def verify_greater_than(self, first, second, msg=''):
        """Assert if first not equal to second or not."""
        try:
            self.verify_true((first > second), msg=msg)
        except AssertionError:
            raise AssertionError(
                f'verify校验, {first} 预期大于 {second}, 校验失败:{msg}')


verify = Verify()
