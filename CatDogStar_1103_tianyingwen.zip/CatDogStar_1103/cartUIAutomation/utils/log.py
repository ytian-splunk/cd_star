#!/usr/bin/env python3
# -*- code:utf-8 -*-
'''
@File: log.py
@Author: Tian Yingwen
@Date: 2025/10/20
'''

import logging
import os
import sys
import platform
import colorlog
import re
from datetime import datetime


cur_path = os.path.dirname(os.path.abspath(__file__))

# default.job file path
if platform.system().lower() == 'windows':  # 此步骤为预判，因脚本在Mac上调试
    split_dir = cur_path.split('\\')[:-1]
    DEFAULT_JOB_PATH = f"{'/'.join(split_dir)}/default.job"
else:
    DEFAULT_JOB_PATH = os.path.join('/'.join(cur_path.split('/')[:-1]),
                                    'default.job')

LOG_DIR = os.path.join(os.path.split(DEFAULT_JOB_PATH)[0], 'logs')

log_colors_config = {
    'DEBUG': 'white',  # cyan white
    'INFO': 'green',
    'WARNING': 'yellow',
    'ERROR': 'red'
}

# ~/autotest/testCase/default.job
if platform.system().lower() == 'windows':  # 此步骤为预判，因脚本在Mac上调试
    parent_dir = '/'.join(
        os.path.dirname(os.path.dirname(__file__)).split('\\'))
    job_file_path = f'{parent_dir}/default.job'
else:
    job_file_path = f'{os.path.dirname(os.path.dirname(__file__))}/default.job'

with open(file=job_file_path, mode='r', encoding='utf-8')as f:
    r = f.readline()
    job_id = r.split(':')[1].strip()


class Filter(logging.Filter):
    def filter(self, record):
        if record.msg is not None:
            return True


class Logger(object):
    """日志处理"""

    def __init__(self):
        if not os.path.exists(LOG_DIR):
            os.mkdir(LOG_DIR)

        # 这里判断，如果按照py文件运行的话，就已知了py文件，直接拿过来用即可
        test_name = sys.argv[-1]
        if platform.system().lower() == 'windows':
            if '.py' in test_name:
                # test_name是当前运行case的.py文件的路径
                r = re.search(r'test_.+\.py', test_name)
                location_name = r.group().replace('.py', '')
            else:
                # 这是一个folder
                location_name = test_name.split('\\')[-1]
        else:
            if '.py' in test_name:
                # test_name是当前运行case的.py文件的路径
                r = re.search(r'test_.+\.py', test_name)
                if r:
                    location_name = r.group().replace('.py', '')
                else:
                    location_name = test_name.split('/')[-1]
            else:
                # 这是一个folder
                location_name = test_name.split('/')[-1]

        _date = datetime.strftime(datetime.now(), "%Y-%m-%d")

        # 创建一个日志收集器
        self.logger = logging.getLogger(name=f"log_{_date}.log")
        # 日志空值过滤器 - 过滤None
        self.logger.addFilter(Filter())
        # 指定日志收集器的日志等级 NOTSET-DEBUG-INFO-WARN-ERROR-CRITICAL
        self.logger.setLevel(logging.DEBUG)

        # 定义一个文件输出渠道
        file_handle = logging.FileHandler(
            os.path.join(LOG_DIR, f"{job_id}.{location_name}.{_date}.log"),
            encoding='utf-8')
        # 设置文件输出渠道的日志级别为INFO
        file_handle.setLevel("DEBUG")
        # 定义详细类型日志格式
        verbose_formatter = logging.Formatter(
            "[%(asctime)s][file=>%(myfn)s, line=>%(mylno)d,"
            " 方法=>%(myfunc)s][%(levelname)s]: %(message)s")
        # 文件中显示详细的日志
        file_handle.setFormatter(verbose_formatter)

        # 将日志收集器与输出渠道对接
        self.logger.addHandler(file_handle)
        self.init_logger()

    def init_logger(self):
        # 定义一个控制台输出渠道
        console_handle = logging.StreamHandler()

        console_formatter = colorlog.ColoredFormatter(
            fmt="\n\033[1;%(colorcode)sm"  # 颜色格式化,开始
                "[%(levelname)s: %(asctime)s "
                "文件：%(myfn)s:%(mylno)d 方法：%(myfunc)s] Message: \n"
                "%(log_color)s%(message)s.\033[1m",  # 颜色格式化,结束
            datefmt='%Y-%m-%d %H:%M:%S',
            log_colors=log_colors_config)

        console_handle.setFormatter(fmt=console_formatter)
        self.logger.addHandler(console_handle)

    def update_log_info(self, kwargs, color_code):
        try:
            fn, lno, func, sinfo = self.logger.findCaller()
            fndir = os.path.dirname(fn)
            fn = os.path.basename(fn)
        except Exception as e:
            fn, lno, func = "(unknown file)", 0, "(unknown function)"

        if "extra" not in kwargs:
            kwargs["extra"] = {}

        kwargs['extra']['myfn'] = fn
        kwargs['extra']['mylno'] = lno
        kwargs['extra']['myfunc'] = func
        kwargs['extra']['colorcode'] = color_code
        kwargs['extra']['mymodule'] = ""
        kwargs['extra']['myfndir'] = fndir

    def debug(self, msg, *args, **kwargs):
        self.update_log_info(kwargs, "37")
        self.logger.debug(msg=msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        self.update_log_info(kwargs, '36')
        self.logger.info(msg, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        self.update_log_info(kwargs, '33')
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self.update_log_info(kwargs, '31')
        self.logger.error(msg, *args, **kwargs)

logger = Logger()
