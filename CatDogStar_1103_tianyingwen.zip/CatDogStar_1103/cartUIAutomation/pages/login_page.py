#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: login_page.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

from playwright.sync_api import Page
from cartUIAT.pages.base_page import BasePage
from cartUIAT.config.config import LOGIN_URL


class LoginPage(BasePage):
    """
    登录页面类，封装登录页面的元素和操作
    """
    def __init__(self, page: Page):
        super().__init__(page)
    
    def navigate(self):
        """
        导航到登录页面
        """
        super().navigate(LOGIN_URL)
        try:
            self.page.get_by_role("button", name="Proceed").click()
        except:
            pass
    
    def enter_username(self, username):
        """
        输入用户名
        :param username: phone or email
        """
        enter_into = self.page.get_by_placeholder("請輸入", exact=True)
        enter_into.click()
        enter_into.fill(username)

    def click_login(self):
        """
        点击登录按钮
        """
        self.page.get_by_role("button", name="登入/註冊").click()

    def login(self, username: str):
        """
        完整登录流程
        :param username: phone or email
        """
        self.navigate()
        self.enter_username(username)
        self.click_login()
        # 等待登录完成，可以根据实际情况调整等待条件
        self.wait.wait_for_url("**/home")
