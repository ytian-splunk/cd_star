#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: home_page.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

from .base_page import BasePage
from cartUIAT.config.config import BASE_URL
from cartUIAT.utils.log import logger


class HomePage(BasePage):
    """首页页面对象"""
    
    # 页面URL
    PATH = BASE_URL
    
    # 页面元素选择器
    LOGIN_LINK = ".login-link"
    CATEGORY_MENU = ".category-menu"
    SEARCH_BOX = "#search-box"
    SEARCH_BUTTON = "#search-button"
    CART_ICON = ".cart-icon"
    USER_NAME = ".user-name"
    CAT_ZONE_LINK = 'https://www.dogcatstar.com/product-category/cat'
    CAT_ZONE_XPATH = 'xpath=//*[@id="react-pc-nav"]/div/div/div/div[2]/a/img'

    def __init__(self, page):
        super().__init__(page)

    def navigate(self) -> None:
        """导航到首页"""
        logger.info('导航到首页')
        super().navigate(self.PATH)
        try:
            self.page.get_by_role("button", name="Proceed").click()
        except:
            pass

    # 打开猫猫专区
    def click_cat_zone(self):
        """
        点击首页顶部的【猫猫专区】，进入猫猫商品页面
        """
        logger.info('点击首页顶部的【猫猫专区】，进入猫猫商品页面')
        self.page.locator(self.CAT_ZONE_XPATH).click()

    def click_login_link(self) -> None:
        """点击登录链接"""
        self.click(self.LOGIN_LINK)
    
    def search_product(self, keyword: str) -> None:
        """搜索商品"""
        self.fill(self.SEARCH_BOX, keyword)
        self.click(self.SEARCH_BUTTON)
    
    def click_category(self, category_name: str) -> None:
        """点击分类菜单"""
        category_selector = f"{self.CATEGORY_MENU} li:has-text('{category_name}')"
        self.click(category_selector)
    
    def click_cart_icon(self) -> None:
        """点击购物车图标"""
        self.click(self.CART_ICON)
    
    def is_user_logged_in(self) -> bool:
        """检查用户是否已登录"""
        return self.is_visible(self.user_name)
    
    def get_logged_username(self) -> str:
        """获取已登录用户名"""
        return self.get_text(self.user_name)
