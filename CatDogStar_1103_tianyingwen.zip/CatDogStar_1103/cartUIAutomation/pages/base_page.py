#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: base_page.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

from playwright.sync_api import Page
from cartUIAT.utils.wait_strategies import WaitStrategies


class BasePage:
    """
    基础页面类，封装通用的页面操作方法
    """
    
    def __init__(self, page: Page):
        self.page = page
        self.wait = WaitStrategies(page)
    
    def navigate(self, url: str):
        """
        导航到指定URL
        """
        self.page.goto(url, timeout=60_000)
        # self.wait.wait_for_network_idle()
    
    def click(self, selector: str):
        """
        点击元素
        """
        self.wait.wait_for_element_visible(selector)
        self.page.click(selector)
    
    def fill(self, selector: str, value: str):
        """
        填充文本
        """
        self.wait.wait_for_element_visible(selector)
        self.page.fill(selector, value)
    
    def get_text(self, selector: str) -> str:
        """
        获取元素文本
        """
        self.wait.wait_for_element_visible(selector)
        return self.page.locator(selector).text_content().strip()
    
    def is_element_visible(self, selector: str) -> bool:
        """
        检查元素是否可见
        """
        try:
            self.wait.wait_for_element_visible(selector, timeout=2)
            return True
        except TimeoutError:
            return False
    
    def get_element_count(self, selector: str) -> int:
        """
        获取元素数量
        """
        return self.page.locator(selector).count()
    
    def wait_for_page_load(self):
        """
        等待页面加载完成
        """
        self.wait.wait_for_network_idle()
    
    def take_screenshot(self, name: str) -> str:
        """
        截取当前页面截图
        """
        return self.page.screenshot(path=f"screenshots/{name}.png",
                                    full_page=True)
