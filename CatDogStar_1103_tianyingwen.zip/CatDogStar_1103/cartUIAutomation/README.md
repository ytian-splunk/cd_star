# StarUI 自动化测试项目

## 项目概述

这是一个针对 `https://www.dogcatstar.com` 网站的自动化测试项目，专注于测试商品添加购物车功能。项目使用 Python、Playwright 和 Allure 构建，采用 pytest 和 Page Object 模式设计。

## 技术栈
- **Python**: 3.8+
- **Playwright**: 用于浏览器自动化
- **pytest**: 测试框架
- **Allure**: 测试报告生成工具
- **Page Object 模式**: 用于封装页面操作

## 项目结构
```
cartUIAT/
├── config/                # 配置文件
│   └── config.py          # 项目配置
├── pages/                 # 页面对象
│   ├── base_page.py   # 基础页面类
│   ├── login_page.py      # 登录页面类
│   ├── product_list_page.py  # 商品列表页面类
│   └── cart_page.py       # 购物车页面类
├── tests/                 # 测试用例
│   ├── conftest.py        # pytest配置
│   └── test_add_to_cart.py  # 商品添加购物车测试
├── utils/                 # 工具类
│   ├── auth_utils.py      # 认证工具
│   └───── wait_strategies.py  # 等待策略工具
├── allure-results/        # Allure测试结果（自动生成）
├── allure-report/         # Allure测试报告（自动生成）
├── screenshots/           # 测试截图（自动生成）
├── run_tests.py           # 测试运行脚本
├── requirements.txt       # 项目依赖
└── README.md              # 项目说明
```

## 安装与配置
### 安装依赖
```bash
pip install -r requirements.txt
playwright install
```

### 配置用户凭据
编辑 `config/config.py` 文件，设置正确的用户凭据：

```python
USER_CREDENTIALS = {
    "username": "your_username",
    "password": "your_password"
}
```

## 运行测试
### 方法一：使用运行脚本
```bash
python run_tests.py
```

### 方法二：直接使用pytest
```bash
pytest -sv tests/ --alluredir=allure-results --clean-alluredir
```

### 查看测试报告
测试完成后，生成Allure报告：
```bash
allure generate allure-results -o allure-report --clean
allure serve allure-results
```

## 等待策略说明
本项目采用了智能等待策略，结合了Playwright的自动等待和显式等待：
1. **自动等待**: Playwright内置的自动等待机制，会自动等待元素可见、可交互。
2. **等待时间配置**:
   - `WAIT_SHORT`: 2秒，用于快速操作
   - `WAIT_MEDIUM`: 5秒，用于一般操作
   - `WAIT_LONG`: 10秒，用于耗时操作

## 测试用例说明
本项目包含以下测试场景：
1. **从商品列表页添加商品到购物车**: 测试基本的商品添加功能
2. **验证购物车中的商品信息**: 验证添加到购物车的商品信息是否正确

## 扩展建议，未来优化空间
1. **添加更多测试用例**: 可以扩展测试用例，覆盖更多功能点，如用户注册、商品搜索、下单流程等。
2. **数据驱动测试**: 使用pytest的参数化功能，实现数据驱动测试。
3. **持续集成**: 将测试集成到CI/CD流程中，实现自动化测试。
4. **并行执行**: 自己开发并行策略，或者使用pytest-xdist插件，实现测试用例的并行执行，提高测试效率。
5. 设计并行执行testcase的方案，随着case数量的递增，可以有效的缩短全量case的执行时间
6. 自由区分不同环境的配置，比如：Test环境、Stage环境、Dev环境、Online环境等
7. 落实每日巡检；生产环境可以做到每n个小时巡检一次，落实测试结果通过邮件、企微或钉钉发送的机制

