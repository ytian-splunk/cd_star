#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: conftest.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""
import pytest
from playwright.sync_api import sync_playwright, Browser, Page, BrowserContext
from cartUIAT.pages.login_page import LoginPage
from cartUIAT.pages.home_page import HomePage
from cartUIAT.pages.cart_page import CartPage
from cartUIAT.utils.auth_utils import load_auth_state
from cartUIAT.utils.auth_utils import clear_auth_state
from cartUIAT.utils.auth_utils import login_and_save_auth_state
from cartUIAT.config.config import STORAGE_STATE_PATH
from cartUIAT.config.config import BASE_URL

@pytest.fixture(scope="session")
def browser():
    """
    会话级别的浏览器夹具，整个测试会话只只启动一次浏览器
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,  # 调试时设置为False，实际运行时可设置为True
            slow_mo=1000,  # 减缓操作速度，便于观察
            args=[
                "--start-maximized",  # 最大化窗口
                "--disable-extensions",  # 禁用扩展
            ]
        )
        yield browser

        browser.close()

@pytest.fixture(scope="session")
def authenticated_context(browser):
    """
    带有认证状态的上下文夹具，整个测试会话共享
    """
    """---------- 因网络限制暂时不执行 -------------"""
    # # 检查是否已有保存的认证状态
    # if not load_auth_state():
    #     # 如果没有，执行登录并保存状态
    #     login_and_save_auth_state()

    # 使用保存的认证状态创建上下文
    # context = browser.new_context(storage_state=STORAGE_STATE_PATH)
    context = browser.new_context()

    # # 启用视频录制
    # context.start_video()

    yield context
    
    # 停止视频录制并关闭上下文
    # context.stop_video()
    context.close()
    
    # 可选：测试结束后清除认证状态
    # clear_auth_state()

@pytest.fixture(scope="function")
def page(authenticated_context):
    """
    函数级别的页面夹具，每个测试函数都会创建一个新页面
    """
    page = authenticated_context.new_page()
    
    # 设置页面视图大小
    page.set_viewport_size({"width": 1440, "height": 720})
    
    yield page
    
    # 关闭页面
    page.close()

@pytest.fixture(scope="function")
def home_page(page):
    """
    主页面
    """
    return HomePage(page)

@pytest.fixture(scope="function")
def login_page(page):
    """
    登录页面
    """
    return LoginPage(page)

@pytest.fixture(scope="function")
def cart_page(page):
    """
    购物车页面
    """
    return CartPage(page)

@pytest.fixture(scope="function", autouse=False)
def setup_and_teardown(page, cart_page):
    """
    每个测试函数的前置和后置操作
    """
    # 前置操作：导航到首页
    page.goto(BASE_URL)
    
    # 确保购物车为空
    cart_page.navigate_to_cart()
    if not cart_page.is_cart_empty():
        cart_page.clear_cart()
    
    yield
    
    # 后置操作：清除购物车
    cart_page.navigate_to_cart()
    if not cart_page.is_cart_empty():
        cart_page.clear_cart()
