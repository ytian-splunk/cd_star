1. 目录【cartUIAutomation】：python+playwright+pytest的UI自动化
