#!/usr/bin/env python3
# -*- code:utf-8 -*-
'''
@File: log
@Author: Tian Yingwen
@Date: 2025/10/20
'''

import logging
import os


class Logger(object):
    """日志处理"""


logger = Logger()
