#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: __init__.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""


"""
一些常规的通用的封装，比如：
1 通用的class、methods和tools
2 requests的封装
3 verify的封装
4 log的封装
5 exception
"""
