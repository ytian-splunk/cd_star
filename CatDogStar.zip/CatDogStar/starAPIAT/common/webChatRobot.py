#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: weChatRobot.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

"""用于企微或钉钉发送通知"""
