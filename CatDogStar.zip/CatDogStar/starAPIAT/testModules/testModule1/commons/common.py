#!/usr/bin/env python3
# -*- code:utf-8 -*-

import sys
import time


class ClassName(object):

    def __init__(self):
        pass

    def method_01(self):
        pass

    def method_02(self):
        pass
