#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import pytest
import allure


@allure.epic('epic')
@allure.feature('feature')
@allure.story('story')
class TestStoryCase:
    def setup_class(self):
        """根据实际需求设计"""
        pass

    def setup_method(self):
        """根据实际需求设计"""
        pass

    def teardown_method(self):
        """根据实际需求设计"""
        pass

    def teardown_class(self):
        """根据实际需求设计"""
        pass

    @allure.title('title')
    @pytest.mark.P1
    def test_testcase1(self):
        """
        case step 1
        case step 2
        case step 3
        """


    @allure.title('title')
    @pytest.mark.P1
    def test_testcase2(self):
        """
        case step 1
        case step 2
        case step 3
        """
