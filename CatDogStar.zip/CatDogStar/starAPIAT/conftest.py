#!/usr/bin/env python3
# -*- code:utf-8 -*-
"""
fixture  hook等
"""
