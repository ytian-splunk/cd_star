#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: __init__.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""


"""
配置文件、配置参数等
"""
