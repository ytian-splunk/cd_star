#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: __init__.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""


"""
每个模块中，不同测试用例参数化时，按照对应模块，对应case，存放yaml、json、文件、数据等
"""
