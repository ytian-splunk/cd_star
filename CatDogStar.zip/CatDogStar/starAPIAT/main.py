#!/usr/bin/env python3
# -*- code:utf-8 -*-
'''
此为一个大致的分布式自动化轮廓走向，续根据具体业务需求，进行逻辑上的定制开发；
通过设定参数，接收测试用例路径，解析测试用例数量，启动容器进行测试，可集合Jenkins使用；
'''

import docker
from concurrent.futures.thread import ThreadPoolExecutor


def docker_run_test(test_path):
    """启动docker containers的封装"""

    # 创建容器, 执行测试
    d.containers.run(
        image='image',
        name='container_name',
        detach=True,  # container run backend
        stdin_open=bool(True),  # input while attach
        tty=bool(True),  # attach
        working_dir='container_proj_path',
        labels=['CONTAINER_LABEL'],
        volumes={
            '/etc/hosts': {'bind': '/etc/hosts', 'mode': 'ro'},
            # mount: docker.sock file, exec docker command in container
            '/var/run/docker.sock': {
                'bind': '/var/run/docker.sock', 'mode': 'rw'},
            # mount: allure result dir
            'local_result':
                {'bind': f'container_proj_path/reports', 'mode': 'rw'},
            # mount: local and container project dir
            'local_proj_home':
                {'bind': '/home/autotest', 'mode': 'rw'}},
        command='cmd')


if __name__ == '__main__':
    """
    通过设定参数，接收测试用例路径，解析测试用例数量，启动容器进行测试，可集合Jenkins使用
    """
    d = docker.from_env()
    dir_list = ['测试用例列表']
    concurrent_cnt = '并行数量，可配置'
    # 如果实际测试容器数量需求,小于预期容器数量,以实际容器数量为准
    # 创建容器
    with ThreadPoolExecutor(max_workers=concurrent_cnt) as e:
        results = e.map(docker_run_test, dir_list[:concurrent_cnt])
