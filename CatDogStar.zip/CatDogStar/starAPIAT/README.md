# API自动化，分布式框架

### 框架技术栈   python3.8 + pytest + allure
    1、 生成和安装requirement文件
        pip install pipreqs -i https://pypi.douban.com/simple
        pipreqs ./
    2、 安装requirement文件
        pip install -r requirements.txt
    
    3、 pytest.ini 配置文件
        文件配置： pytest.ini
    
    4、 pytest运行规则介绍
        a. 在cmd-cli中输入命令pytest
            1. 在当前路径执行pytest命令， 先进入当前项目下找pytest.ini文件
            2. 按照pytest中配置的执行命令addopts， 以及测试路径testpaths和对应的匹配规则执行
            3. 然后按作用域检查每个作用域下是否有对应的conftest，执行conftest中符合规则的方法
            4. 再执行testModule.py中的testCase
    
    5、 提交分支
        1. master分支受保护， 不可push
        2. 新功能开发，建立自己的本地分支: git checkout -b name/feature-time
        3. 提交：
            a. 切换到本地master分支 - 更新本地master(最新代码)
            b. pull远程master代码至本地master - git pull
            c. 切换到新功能分支， 合并新功能代码 - git merge master
            d. push到origin的新分支 - git push origin name/feature-time
        4. 提交工单，合并至origin的master分支
        5. 审核-完成
        other: 
            删除分支 git branch -D name/feature-time
            切换分支 git checkout name/feature-time

### 命名规则
    folder:      小驼峰 testLogin
    module：     小驼峰 testLogin
    class：      大驼峰 TestLogin
    function：   test_login
    函数中的参数：  test_login
    环境变量：     大写  TEST
    全局变量：     大写  TEST
    变量：        test_login
    私有：        _test 
    描述：   每个参数尽量表达意思清晰  推荐： resLogin  ==> 登录接口返回  不推荐： res/a/s/l这些看不明白含义的命名
    
### 分层思想：
        common、 testData、reports、testModules
### common：
        常规方法
            testCase/apiPath      仅调用所有api的路径，不需要每个feature的common中再重写
       全局初始化数据
            account_config.yaml   全局公用的账户和密码, 普通用户和管理员账户, 在public.py, 或者Gemini类中获取
            space_config.yaml     全局空间, 在public.py, 或者Gemini类中获取
            image_config.yaml     默认初始化的镜像仓库和镜像, 在public.py, 或者Gemini类中获取
            project_config.yaml     默认初始化的公开项目, 在public.py, 或者Gemini类中获取
            dataset_config.yaml     默认初始化的数据集, 在public.py, 或者Gemini类中获取
            datasource_config.yaml     默认初始化的数据源, 在public.py, 或者Gemini类中获取

### logs：
        log： 仅用于存放log

### feature-common：
        common： 单接口封装方法，公用流程组合；类似于UI自动化测试的PageObject模块

### feature-case：testModules
        1. 流程性case：  
            a. 命名： 按照case模块， case文件名称， case文件序号命名， 写业务流程case
            b. 前置后置： 写流程类用例，需要设置前置case和后置case， 然后在执行体中执行，前置setup 后置 teardown
                1. step： 采用allure中的step方法， 在每个步骤之前
                2. teardown: 所有case测试完成, 做好清理工作
                3. log: 每个请求后有log， 封装到methods中
            e. verify&assert: 校验失败，添加内容说明； 方便通过log查看问题所在
        2. 业务case参数： pytest结合parameter   ---预留，可以不加这种模式

### feature-data: testData
        对应的testModules测试用例需要的数据

### conftest.py
        1. 按用户习惯添加
        2. 可以在单独测试模块目录下添加, 或者在总目录下添加


## 项目结构
```
starAPIAT/
├── apiPath/                # 各个功能模块的API
│   └── model_api.py        # 项目配置
├── common/                 # 一些常规的通用的封装
│   ├── log.py              # 日志的封装
│   ├── tools.py            # 通用工具的封装
│   └── verify.py           # 断言的封装
├── config/                 # 配置文件、配置参数等
├── logs/                   # 保存日志文件，仅用于存放log
│   └── log.log             # 日志文件
├── allure-results/         # Allure测试结果（自动生成）
├── reports/                # 存放allure报告
├── testData/               # 各个测试模块中，测试用例参数化的yaml、json、文件、数据等
├── testModele/             # 各个模块的测试用例
│   └── testModele1/        # 测试模块名称
│       └── test_cases.py   # 测试文件名称，testCase写在这个文件中
│   └── testModele2/        # 测试模块名称
│        └── test_cases.py  # 测试文件名称，testCase写在这个文件中
├── requirements.txt        # 项目依赖
├── main.py                 # 并行执行testcase的主入口
├── default.job             # 预留的配置文件，可结合Jenkins使用
├── pytest.ini              # pytest配置文件
├── conftest.py             # fixture  hook等，比如一些初始化或者清理工作
└── README.md               # 项目说明
```
