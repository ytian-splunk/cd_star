1. 目录【cartUIAT】：python+playwright的UI自动化
2. 目录【starUIAT】：API自动化，分布式测试框架，文件【购物车页几个接口及API自动化设计.docx】会引用到
