#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: config.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

"""
配置文件，包含测试所需的常量和配置信息
"""

# 网站基础URL
BASE_URL = "https://www.dogcatstar.com"

# 登录页面URL
LOGIN_URL = f"{BASE_URL}/my-account"

# 猫猫专区：商品列表页面URL
CAT_PRODUCT_LIST_URL = f"{BASE_URL}/product-category/cat"

# 购物车页面URL
CART_URL = f"{BASE_URL}/cart"

# 用户凭据（实际测试时请使用环境变量或配置文件）
USER_CREDENTIALS = {
    "username": "test_user",
    "password": "test_password"
}

# 存储状态文件路径
STORAGE_STATE_PATH = "auth_state.json"

# 等待时间配置（秒）
WAIT_SHORT = 20
WAIT_MEDIUM = 50
WAIT_LONG = 100
