#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: run_tests.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

import subprocess
import os
import sys


def run_tests():
    """
    运行测试并生成Allure报告
    """
    # try:
        # 检查是否安装了必要的依赖
        # check_dependencies()

    # 创建截图目录
    os.makedirs("screenshots", exist_ok=True)

    # 运行测试并生成Allure报告
    print("开始执行测试...")
    result = subprocess.run(
        [
            "pytest",
            "-sv",
            "tests/",
            "--alluredir=allure-results",
            "--clean-alluredir",
            # "--capture=tee-sys"
        ],
        # check=True,
        # stdout=subprocess.PIPE,
        # stderr=subprocess.PIPE,
        # text=True
    )

    print("测试执行完成，生成Allure报告...")

    # 生成Allure报告
    subprocess.run(
        ["allure", "generate", "allure-results", "-o", "allure-report", "--clean"],
        check=True
    )

    print("Allure报告已生成，路径: allure-report/index.html")
    print("可以使用以下命令在浏览器中查看报告: allure serve allure-results")
        
        # return 0
    #
    # except subprocess.CalledProcessError as e:
    #     print(f"测试执行失败: {e.stderr}")
    #     return 1
    # except Exception as e:
    #     print(f"运行测试时出现错误: {str(e)}")
    #     return 1

# def check_dependencies():
#     """
#     检查是否安装了必要的依赖
#     """
#     try:
#         # 检查pytest
#         subprocess.check_output(["pytest", "--version"])
#
#         # 检查playwright
#         subprocess.run(["playwright", "--version"], check=True, capture_output=True)
#
#         # 检查allure
#         subprocess.run(["allure", "--version"], check=True, capture_output=True)
#
#         print("所有必要依赖已依赖都已安装")
#
#     except subprocess.CalledProcessError:
#         print("正在安装必要的依赖...")
#
#         # 安装pytest和playwright
#         subprocess.run([
#             sys.executable, "-m", "pip", "install",
#             "pytest", "playwright", "allure-pytest", "pytest-html"
#         ], check=True)
#
#         # 安装playwright浏览器
#         subprocess.run(["playwright", "install"], check=True)
#
#         print("依赖安装完成")


if __name__ == "__main__":
    sys.exit(run_tests())
