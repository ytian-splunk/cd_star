#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: cart_page.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

from playwright.sync_api import Page
from cartUIAT.pages.base_page import BasePage
from cartUIAT.config.config import CART_URL
from cartUIAT.utils.log import logger


class CartPage(BasePage):
    """
    购物车页面类，封装购物车页面的元素和操作
    """
    
    # 页面元素选择器
    CART_ITEM = '.cart-item'
    CART_ITEM_NAME = '.cart-item-name'
    CART_ITEM_PRICE = '.cart-item-price'
    CART_ITEM_QUANTITY = '.cart-item-quantity'
    CART_ITEM_TOTAL = '.cart-item-total'
    CART_TOTAL = '.cart-total'
    REMOVE_ITEM_BUTTON = '.remove-item-button'
    EMPTY_CART_MESSAGE = '.empty-cart-message'
    
    def __init__(self, page):
        super().__init__(page)
    
    def navigate_to_cart(self):
        """
        导航到购物车页面
        """
        logger.info('导航到购物车页面')
        self.page.get_by_role("link", name="Cart").click()
        try:
            self.page.get_by_test_id("dialog-close-button").click()
        except:
            pass
    
    def get_cart_product_count(self) -> int:
        """
        获取购物车商品数量
        :return int, 购物车商品数量
        """
        # self.navigate_to_cart()
        logger.info('从购物车icon获取购物车中的商品数量')
        count = self.page.get_by_role("listitem").all_inner_texts()[-1]
        cart_cnt = int(count) if count else 0

        return cart_cnt
    
    def is_cart_empty(self) -> bool:
        """
        检查购物车是否为空
        """
        return self.is_element_visible(self.EMPTY_CART_MESSAGE)
    
    def get_cart_item_names(self) -> list:
        """
        获取购物车中所有商品名称
        """
        items = self.page.locator(self.CART_ITEM)
        names = []
        for i in range(items.count()):
            name = items.nth(i).locator(self.CART_ITEM_NAME).text_content().strip()
            names.append(name)

        return names
    
    def get_cart_item_prices(self) -> list:
        """
        获取购物车中所有商品价格
        """
        items = self.page.locator(self.CART_ITEM)
        prices = []
        for i in range(items.count()):
            price = items.nth(i).locator(self.CART_ITEM_PRICE).text_content().strip()
            prices.append(price)
        return prices
    
    def get_cart_item_quantities(self) -> list:
        """
        获取购物车中所有商品数量
        """
        items = self.page.locator(self.CART_ITEM)
        quantities = []
        for i in range(items.count()):
            quantity = items.nth(i).locator(self.CART_ITEM_QUANTITY).text_content().strip()
            quantities.append(quantity)
        return quantities
    
    def get_cart_item_totals(self) -> list:
        """
        获取购物车中所有商品小计
        """
        items = self.page.locator(self.CART_ITEM)
        totals = []
        for i in range(items.count()):
            total = items.nth(i).locator(self.CART_ITEM_TOTAL).text_content().strip()
            totals.append(total)
        return totals
    
    def get_cart_total(self) -> str:
        """
        获取购物车总计金额
        """
        return self.get_text(self.CART_TOTAL)

    def remove_cart_item_by_name(self, product_name: str):
        """
        根据商品名称移除购物车中的商品
        """
        items = self.page.locator(self.CART_ITEM)
        found = False
        
        for i in range(items.count()):
            name = items.nth(i).locator(self.CART_ITEM_NAME).text_content().strip()
            if product_name in name:
                self.remove_cart_item_by_index(i)
                found = True
                break
        
        if not found:
            raise ValueError(f"购物车中未找到商品: {product_name}")
    
    def clear_cart(self):
        """
        清空购物车（循环删除所有商品）
        """
        pass
