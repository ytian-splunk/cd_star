#!/usr/bin/env python3
# -*- coding:utf-8 -*-
"""
@File: test_add_to_cart.py
@Author: Tian Yingwen
@Date: 2025/10/20
"""

import allure
import pytest
import re

from cartUIAT.utils.log import logger
from cartUIAT.utils.verify import verify


@allure.feature("商品添加购物车功能")
@allure.story("用户可以将商品添加到购物车")
class TestAddToCart:
    def setup_class(self):
        logger.info('测试执行setup class')

    def teardown_class(self):
        logger.info('测试执行teardown class')

    @allure.title("从商品列表页，成功添加商品到购物车")
    @pytest.mark.P1
    def test_add_product_to_cart_from_list(self, home_page, cart_page):
        """
        1 导航到首页
        2 获取添加商品前的购物车数量
        3 添加商品到购物车
        4 验证添加商品后的购物车数量
        5 导航到购物车页面
        6 验证商品是否在购物车中
        7 验证购物车中的商品数量
        """
        page = home_page.page
        # 步骤1: 导航到首页
        with allure.step("导航到首页"):
            home_page.navigate()

        # 步骤2: 进入购物车页面，记录商品的数量
        with allure.step("添加商品前，进入购物车页面，记录商品的数量"):
            logger.info('添加商品前，进入购物车页面，记录商品的数量')
            # 添加商品前，进入购物车页面，购物车中商品的数量
            cart_page.navigate_to_cart()
            before_cart_cnt = cart_page.get_cart_product_count()

        # 步骤3：导航到【貓咪專區】
        with allure.step("导航到【貓咪專區】"):
            logger.info('导航到【貓咪專區】页面')
            home_page.click_cat_zone()

        # 步骤4：选择一个商品，添加到购物车
        with allure.step("选择一个商品，添加到购物车"):
            logger.info('从【貓咪專區】页面，选择一个商品，添加到购物车')
            # 选择第一个商品
            first_product = page.locator(".product-small").first
            # 匹配到商品的名称
            inner_text = first_product.inner_text()
            m = re.search(r'\n\n.+\n\n', inner_text)
            product_title_name = m.group().strip()
            # 添加该商品的到购物车
            page.locator(".btn-quick-view").first.click()
            page.get_by_role("button", name="單包（ 5 條）").click()
            page.get_by_test_id("button-add-to-cart").click()

        # 步骤4：添加商品后，进入购物车页面， 购物车商品数量预期+1
        with allure.step('添加商品后，进入购物车页面，购物车商品数量预期+1'):
            logger.info('添加商品后，校验购物车商品数量+1')
            # 添加商品后，进入购物车页面， 购物车商品数量预期+1
            cart_page.navigate_to_cart()
            after_cart_cnt = cart_page.get_cart_product_count()
            verify.verify_equal(
                after_cart_cnt, before_cart_cnt + 1,
                msg=f'添加商品到购物车，测试失败, 预期商品数量: {before_cart_cnt + 1}, '
                    f'实际商品数量: {after_cart_cnt}'
            )

        # 步骤5：购物车页面，校验商品成功添加到了购物车
        with allure.step('购物车页面，校验添加的商品名称正确'):
            logger.info('添加商品后，校验购物车商品名称符合预期')
            # 购物车页面，校验添加的商品名称正确
            cart_product_name = page.get_by_text(
                product_title_name
            ).first.inner_text()
            verify.verify_equal(
                cart_product_name, product_title_name,
                msg=f'添加到购物车中的商品名称不正确，预期:{product_title_name}, '
                    f'实际:{cart_product_name}'
            )
